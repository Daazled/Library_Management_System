/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.*;



public class BookController {

    
    public JTextField txtBookId;
    public JTextField txtTitle;
    public JTextField txtAuthor;
    public JTextField txtYear;
    public JTable tblBook;
    public DefaultTableModel model;
    
    public BookController(JTextField txtBookId, JTextField txtTitle, JTextField txtAuthor,
                          JTextField txtYear, JTable tblBook) {
        this.txtBookId = txtBookId;
        this.txtTitle = txtTitle;
        this.txtAuthor = txtAuthor;
        this.txtYear = txtYear;
        this.tblBook = tblBook;
        this.model = (DefaultTableModel) tblBook.getModel();
    }

   
    
     private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/librarydb"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
    
    public void loadBooks() {
        model.setRowCount(0); // Clear existing data
        String query = "SELECT * FROM books";
        
        try (
                Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                model.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage());
        }
    }
         
     
    public void addBook() {
        String query = "INSERT INTO books (book_id, title, author, year_published) VALUES (?, ?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1, Integer.parseInt(txtBookId.getText()));
            pst.setString(2, txtTitle.getText());
            pst.setString(3, txtAuthor.getText());
            pst.setInt(4, Integer.parseInt(txtYear.getText()));
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book Added Successfully!");
            txtBookId.setText("");
            txtTitle.setText("");
            txtAuthor.setText("");
            txtYear.setText("");
            txtBookId.requestFocus();
            loadBooks();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error adding book: " + ex.getMessage());
        }
    }
    
     public void updateBook() {
        String query = "UPDATE books SET title = ?, author = ?, year_published = ? WHERE book_id = ?";

        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, txtTitle.getText());
            pst.setString(2, txtAuthor.getText());
            pst.setInt(3, Integer.parseInt(txtYear.getText()));
            pst.setInt(4, Integer.parseInt(txtBookId.getText()));
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book Updated Successfully!");
            loadBooks();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error updating book: " + ex.getMessage());
        }
    }
     
    public void deleteBook() {
         DefaultTableModel d1=(DefaultTableModel)tblBook.getModel();
        int selectIndex=tblBook.getSelectedRow();
        int id=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
        
        String query = "UPDATE books SET status='inactive' WHERE book_id=?";

        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1,id);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book inactivated Successfully!");
            loadBooks();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error inactivating book: " + ex.getMessage());
        }
    }
    
     public void clearFields() {
        txtBookId.setText(" ");
        txtTitle.setText(" ");
        txtAuthor.setText(" ");
        txtYear.setText(" ");
    }
    
    
    
    
}

