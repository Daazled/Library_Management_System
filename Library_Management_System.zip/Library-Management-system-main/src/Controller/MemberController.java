/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;
import View.MemberViewForm;


public class MemberController {
    public JTextField txtId;
    public JTextField txtName;
    public JTextField txtContact;
    public JTextField txtAddress;
    public JTextField txtCard;
    public JTextField txtExpiry;
    public JTable tblMember;
    public DefaultTableModel model;
    
    
    public MemberController(JTextField txtId, JTextField txtName, JTextField txtContact,
                          JTextField txtAddress, JTextField txtCard,JTextField txtExpiry, JTable tblMember) {
        this.txtId = txtId;
        this.txtName = txtName;
        this.txtContact = txtContact;
        this.txtAddress = txtAddress;
        this.txtCard=txtCard;
        this.txtExpiry=txtExpiry;
        this.tblMember = tblMember;
        this.model = (DefaultTableModel) tblMember.getModel();
    }
    
     private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/librarydb"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
    
    public void loadMember(){
        model.setRowCount(0); // Clear existing data
        String query = "SELECT * FROM members";
        
        try (
              Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                model.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage());
        }
    }
    
    public void addMember() {
        String query = "INSERT INTO members (memberID, name, contactInfo, address,cardNo,Expiry) VALUES (?, ?, ?, ?,?,?)";

        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1, Integer.parseInt(txtId.getText()));
            pst.setString(2, txtName.getText());
            pst.setString(3, txtContact.getText());
            pst.setString(4,txtAddress.getText());
            pst.setInt(5,Integer.parseInt(txtCard.getText()));
            pst.setString(6,txtExpiry.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book Added Successfully!");
            
            
        txtId.setText("");
        txtName.setText("");
        txtContact.setText("");
        txtAddress.setText("");
        txtCard.setText("");
        txtExpiry.setText("");
        txtId.requestFocus();
        loadMember();   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error adding book: " + ex.getMessage());
        }
    }
    
    public void updateMember() {
        DefaultTableModel d1=(DefaultTableModel)tblMember.getModel();
        int selectIndex=tblMember.getSelectedRow();
        int id=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
      
        String query = "UPDATE members SET name = ?, contactInfo = ?, address = ? ,cardNo=?, Expiry=? WHERE memberID = ?";
        
        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, txtName.getText());
            pst.setString(2, txtContact.getText());
            pst.setString(3, txtAddress.getText());
            pst.setInt(4,Integer.parseInt(txtCard.getText()));
            pst.setString(5,txtExpiry.getText());
            pst.setInt(6, id);
           
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book Updated Successfully!");
             txtId.setText("");
        txtName.setText("");
        txtContact.setText("");
        txtAddress.setText("");
        txtCard.setText("");
        txtExpiry.setText("");
        txtId.requestFocus();
            loadMember();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error updating book: " + ex.getMessage());
        }
    }
    
    public void deleteMember() {
        DefaultTableModel d1=(DefaultTableModel)tblMember.getModel();
        int selectIndex=tblMember.getSelectedRow();
        int id=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
        
        String query = "UPDATE members SET status='inactive' WHERE memberID=?";

        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1,id);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Book Deleted Successfully!");
            loadMember();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error deleting book: " + ex.getMessage());
        }
    }
    
     public void clearFields() {
        txtId.setText("");
        txtName.setText("");
        txtContact.setText("");
        txtAddress.setText("");
        txtCard.setText("");
        txtExpiry.setText("");
    }
}
    
      
   
    
    
    
    

