/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;
import Model.Book;
import java.util.ArrayList;
import java.util.List;

public class SearchController {
    public JComboBox cmbAuthor;
    public JComboBox cmbTitle;
    public JTable tblSearch;
    public DefaultTableModel model;
    
    public SearchController(JComboBox cmbAuthor, JComboBox cmbTitle, JTable tblSearch){
        this.cmbAuthor=cmbAuthor;
        this.cmbTitle=cmbTitle;
        this.tblSearch=tblSearch;
        this.model = (DefaultTableModel) tblSearch.getModel();
    }

   
    
     private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/librarydb"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
    
    public List<Book> search(String bookTitle) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title = ? AND status='active'";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1,bookTitle );
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Book book = new Book(
                    resultSet.getInt("book_id"),
                    resultSet.getString("title"),
                    resultSet.getString("author"),
                    resultSet.getInt("year_published")
                );
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return books;
    }

    public List<Book> search(String authorName, String bookTitle) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE author = ? AND title = ? AND status='active'";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, authorName);
            statement.setString(2, bookTitle);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Book book = new Book(
                    resultSet.getInt("book_id"),
                    resultSet.getString("title"),
                    resultSet.getString("author"),
                    resultSet.getInt("year_published")
                );
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return books;
    }
    
    
    
    public void performSearch() {
        
        String authorName = (String) cmbAuthor.getSelectedItem();
        String bookTitle =(String) cmbTitle.getSelectedItem();

        List<Book> searchResults;

        if (authorName==" " && bookTitle!=null) {
            searchResults = search(bookTitle);
            
        } else if (!authorName.isEmpty() && !bookTitle.isEmpty()) {
            searchResults = search(authorName, bookTitle);
            
        } else {
            System.out.println("Please enter at least the author name.");
            return;
        }
        updateTable(searchResults);
        
    }

    private void updateTable(List<Book> books) {
        String[] columnNames = {"Book ID", "Book Name", "Book Author", "Published Year"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        for (Book book : books) {
            Object[] rowData = {book.getbookId(), book.getTitle(), book.getAuthor(), book.getYear()};
            tableModel.addRow(rowData);
        }

        tblSearch.setModel(tableModel);
        
    }
    
    
    public List<String> getAllAuthors() {
        List<String> authors = new ArrayList<>();
        String sql = "SELECT DISTINCT author FROM books";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                authors.add(resultSet.getString("author"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return authors;
    }

   
    public List<String> getAllBookTitles() {
        List<String> bookTitles = new ArrayList<>();
        String sql = "SELECT DISTINCT title FROM books";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                bookTitles.add(resultSet.getString("title"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookTitles;
    }

   
}


