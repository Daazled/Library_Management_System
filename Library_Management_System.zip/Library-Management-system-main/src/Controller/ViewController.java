/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import Model.Book;
import View.ViewBookDetails;
import java.util.Vector;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class ViewController {

    private ViewBookDetails bookView;
    public JTable tblBook;
    public DefaultTableModel model;
    
    
    public ViewController(JTable tblBook){
        this.tblBook=tblBook;
        this.model = (DefaultTableModel) tblBook.getModel();
    }
    
    
     private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/librarydb"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
     
      public void loadBooks() {
        model.setRowCount(0); // Clear existing data
        String query = "SELECT * FROM books WHERE status='active'";
        
        try (
                Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                model.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage());
        }
    }
        
    }
       

