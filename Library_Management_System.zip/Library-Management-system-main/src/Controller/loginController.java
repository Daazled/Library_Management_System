/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import View.LoginForm;
import javax.swing.*;

public class loginController {
    public JTextField txtUser;
    public JPasswordField txtPass;
    
    public loginController(JTextField txtUser,JPasswordField txtPass){
        this.txtUser=txtUser;
        this.txtPass=txtPass;
    }

    public void insertUser(){
        Connection con=null;
        PreparedStatement pst=null;
        String pass=new String(txtPass.getPassword());
        
        try{
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","");
            
            String sql="INSERT INTO users(username,password)VALUES(?,?)";
            pst=con.prepareStatement(sql);
            pst.setString(1,txtUser.getText());
            pst.setString(2,pass);
            
            int rowsAffected=pst.executeUpdate();
            
            if(rowsAffected>0){
                
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                if (pst !=null)pst.close();
                if(con!=null)con.close();            
            } catch (SQLException ex) {
                Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
}
