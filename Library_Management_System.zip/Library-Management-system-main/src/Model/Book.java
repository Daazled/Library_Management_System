/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

public class Book {
    private int bookId;
    private String title;
    private String author;
    private int publishedYear;
    
    
    public Book(int bookId,String title,String author,int publishedYear){
        this.bookId=bookId;
        this.title=title;
        this.author=author;
        this.publishedYear=publishedYear;
        
    }
    
    public String getTitle(){
        return title;
    }
    
    public int getbookId(){
        return bookId;
    }
    
    public String getAuthor(){
        return author;
    }
    public int getYear(){
        return publishedYear;
    }
    
    
    
    
}
