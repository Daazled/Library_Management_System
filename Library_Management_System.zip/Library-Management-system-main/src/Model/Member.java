/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

public class Member extends User {
    private int memberId;
    private String name;
    private String contactNo;
    private String address;
    private MembershipCard membershipcard;
    
    public Member(String username,String password,int memberId, String name, String contactNo, String address,MembershipCard membershipcard ){
        super(username,password);
        this.memberId=memberId;
        this.name=name;
        this.contactNo=contactNo;
        this.address=address;
        this.membershipcard=membershipcard;
    }
    
    public int getMemberID(){
        return memberId;
    }
    
    public String getName(){
        return name;
    }
    
    public String getContactInfo(){
        return contactNo;
    }
    
    public String getAddress(){
        return address;
    }
    
    public MembershipCard getMembershipcard(){
        return membershipcard;
    }
     @Override
        public String getRole(){
            return "member";
        }
   
   
}


