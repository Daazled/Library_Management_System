/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author mansco
 */
public class MembershipCard {
    private String cardNumber;
        private String expiryDate;

        public MembershipCard(String cardNumber,String expiryDate) {
             this.cardNumber=cardNumber;
                this.expiryDate=expiryDate;
        }
        
        public String getCard(){
            return cardNumber;
           
        }
        
        public String getExpiryDate(){
            return expiryDate;
        }
}
